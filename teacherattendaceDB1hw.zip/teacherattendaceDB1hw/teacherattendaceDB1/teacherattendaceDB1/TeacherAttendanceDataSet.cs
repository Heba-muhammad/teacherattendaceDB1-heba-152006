﻿namespace teacherattendaceDB1 {
    
    
    public partial class TeacherAttendanceDataSet {
        partial class attendacesDataTable
        {
        }
    }
}
