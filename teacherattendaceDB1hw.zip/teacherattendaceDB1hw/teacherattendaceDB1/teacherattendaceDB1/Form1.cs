﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace teacherattendaceDB1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void attendacesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.attendacesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.teacherAttendanceDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'teacherAttendanceDataSet1.rooms' table. You can move, or remove it, as needed.
            this.roomsTableAdapter.Fill(this.teacherAttendanceDataSet1.rooms);
            // TODO: This line of code loads data into the 'teacherAttendanceDataSet1.teachers' table. You can move, or remove it, as needed.
            this.teachersTableAdapter.Fill(this.teacherAttendanceDataSet1.teachers);
            // TODO: This line of code loads data into the 'teacherAttendanceDataSet1.courses' table. You can move, or remove it, as needed.
            this.coursesTableAdapter.Fill(this.teacherAttendanceDataSet1.courses);
            // TODO: This line of code loads data into the 'teacherAttendanceDataSet1.attendaces' table. You can move, or remove it, as needed.
            this.attendacesTableAdapter1.Fill(this.teacherAttendanceDataSet1.attendaces);
            // TODO: This line of code loads data into the 'teacherAttendanceDataSet.attendaces' table. You can move, or remove it, as needed.
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = "Server=الا;Database=TeacherAttendance;Trusted_Connection=true";
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            // MessageBox.Show("Connection Open  !");
            SqlCommand command;
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sql = "";
            sql = "INSERT INTO courses(course_name) values ( '" + comboBox1.Text + "')";
            command = new SqlCommand(sql, cnn);
            adapter.InsertCommand = new SqlCommand(sql, cnn);
            adapter.InsertCommand.ExecuteNonQuery();
            command.Dispose();
            ///////////////////////////////////////////////////////////////////////
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            // MessageBox.Show("Connection Open  !");
            SqlCommand command1;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            string sql1 = "";
            sql1 = "INSERT INTO teachers(teacher_name) values ( '" + comboBox2.Text + "')";
            command1 = new SqlCommand(sql1, cnn);
            adapter1.InsertCommand = new SqlCommand(sql1, cnn);
            adapter1.InsertCommand.ExecuteNonQuery();
            command1.Dispose();
            ///////////////////////////////////////////////////////////////////////////////
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            // MessageBox.Show("Connection Open  !");
            SqlCommand command2;
            SqlDataAdapter adapter2 = new SqlDataAdapter();
            string sql2 = "";
            sql2 = "INSERT INTO rooms(room_name) values ( '" + comboBox3.Text + "')";
            command2 = new SqlCommand(sql2, cnn);
            adapter2.InsertCommand = new SqlCommand(sql2, cnn);
            adapter2.InsertCommand.ExecuteNonQuery();
            command2.Dispose();

            //////////////////////////////////////////////////////////////////////////////
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            SqlCommand comm;
            SqlDataAdapter adap = new SqlDataAdapter();
            string srs = "";
            srs = "SELECT course_name from courses WHERE course_id=course_id ";
            comm = new SqlCommand(srs, cnn);
            /////////////////////////////////////////////////////////////////////////////
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            SqlCommand comm1;
            SqlDataAdapter adap1 = new SqlDataAdapter();
            string teach = "";
            teach = "SELECT teacher_name from teachers WHERE teacher_id=teacher_id ";
            comm1 = new SqlCommand(teach, cnn);
            ////////////////////////////////////////////////////////////////////////////
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            SqlCommand comm2;
            SqlDataAdapter adap2 = new SqlDataAdapter();
            string room = "";
            room = "SELECT room_name from rooms WHERE room_id=room_id ";
            comm2 = new SqlCommand(room, cnn);
            ////////////////////////////////////////////////////////////////////////////
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            // MessageBox.Show("Connection Open  !");
            SqlCommand command3;

            SqlDataAdapter adapter3 = new SqlDataAdapter();

            string sql3 = "";
            string date = dateTimePicker1.Value.ToShortDateString();
            TimeSpan tstart = dateTimePicker2.Value.TimeOfDay;
            TimeSpan tleave = dateTimePicker3.Value.TimeOfDay;
            sql3 = "INSERT INTO attendaces(date,start_time,leave_time,course_name,room_name,teacher_name) values('" + date + "','" + tstart + "','" + tleave + "','" + comboBox1.Text + "','" + comboBox3.Text + "','" + comboBox2.Text + "')";
            command3 = new SqlCommand(sql3, cnn);
            adapter3.InsertCommand = new SqlCommand(sql3, cnn);
            adapter3.InsertCommand.ExecuteNonQuery();
            command3.Dispose();
            cnn.Close();
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";

        }

        private void attendacesDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }
        
    }
}
